run java MenuScreen for text version
run java BattleShipGUI for gui version
	- for now, changing modes from AI vs Pl or PvP is done by commenting line 35 in BattleShipGUI class
